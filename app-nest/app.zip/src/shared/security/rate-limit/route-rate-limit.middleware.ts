import { Injectable, type NestMiddleware } from "@nestjs/common";
import { ConfigService } from "@nestjs/config";
import type { NextFunction, Request, Response } from "express";
import type { RedisClientType } from "redis";

import { AppLogger } from "../../logging/app-logger.service.js";
import { RedisService } from "../../redis/redis.service.js";
import {
  keyByIp,
  normalizeApiKey,
  normalizeBodyTarget,
  normalizeCredentialEmail,
  normalizeGetAddress,
  normalizeGetDomain,
  normalizeGetName,
  normalizeGetTo,
  normalizeGetToken,
  normalizeRouteTarget,
} from "./rate-limit.helpers.js";

type RateLimitSettings = {
  redisPrefix: string;
  globalPerMin: number;
  subscribeSlowDelayAfter: number;
  subscribeSlowDelayStepMs: number;
  subscribePer10MinPerIp: number;
  subscribePerHourPerTo: number;
  subscribePerHourPerAlias: number;
  confirmPer10MinPerIp: number;
  confirmPer10MinPerToken: number;
  unsubscribeSlowDelayAfter: number;
  unsubscribeSlowDelayStepMs: number;
  unsubscribePer10MinPerIp: number;
  unsubscribePerHourPerAddress: number;
  checkdnsPer10MinPerTarget: number;
  requestUiPerMinPerIp: number;
  requestUiPer10MinPerTarget: number;
  requestEmailPer10MinPerIp: number;
  requestEmailPerHourPerTarget: number;
  credentialsCreatePerHourPerIp: number;
  credentialsCreatePerHourPerEmail: number;
  credentialsConfirmPer10MinPerIp: number;
  credentialsConfirmPer10MinPerToken: number;
  aliasListPerMinPerKey: number;
  aliasCreatePerMinPerKey: number;
  aliasDeletePerMinPerKey: number;
};

type CounterState = {
  count: number;
  resetMs: number;
};

type RuleBase = {
  name: string;
  windowMs: number;
  key: (request: Request) => string;
};

type DelayRule = RuleBase & {
  kind: "delay";
  delayAfter: number;
  delayMs: (hits: number) => number;
};

type LimitRule = RuleBase & {
  kind: "limit";
  limit: number;
  message: string | Record<string, unknown>;
};

type Rule = DelayRule | LimitRule;

type MemoryCounter = {
  count: number;
  expiresAt: number;
};

const GLOBAL_LIMIT_MESSAGE = "Too many requests, please try again later.";
const REDIS_BACKOFF_MS = 10_000;
const MEMORY_CLEANUP_THRESHOLD = 5_000;

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

@Injectable()
export class RouteRateLimitMiddleware implements NestMiddleware {
  private readonly settings: RateLimitSettings;
  private readonly counters = new Map<string, MemoryCounter>();
  private readonly redisKeyPrefix: string;
  private redisUnavailableUntil = 0;

  constructor(
    configService: ConfigService,
    private readonly redisService: RedisService,
    private readonly logger: AppLogger,
  ) {
    this.settings = configService.getOrThrow<RateLimitSettings>("rateLimit");
    this.redisKeyPrefix = this.settings.redisPrefix || "rl:";
  }

  async use(req: Request, res: Response, next: NextFunction): Promise<void> {
    const rules = this.resolveRules(req);
    if (rules.length === 0) {
      next();
      return;
    }

    try {
      for (const rule of rules) {
        if (rule.kind === "delay") {
          const delayed = await this.applyDelayRule(rule, req);
          if (delayed > 0) {
            await sleep(delayed);
          }
          continue;
        }

        const limited = await this.applyLimitRule(rule, req, res);
        if (limited) {
          return;
        }
      }

      next();
    } catch (error) {
      this.logger.logError("ratelimit.middleware.error", error, req);
      next();
    }
  }

  private resolveRules(req: Request): Rule[] {
    const method = req.method.toUpperCase();
    const path = req.path;

    if (method === "GET" && path === "/forward/subscribe") {
      return [
        this.globalLimitRule(),
        {
          kind: "delay",
          name: "sub_slow_ip",
          windowMs: 60_000,
          delayAfter: this.settings.subscribeSlowDelayAfter,
          delayMs: (hits) =>
            Math.max(
              0,
              (hits - this.settings.subscribeSlowDelayAfter) *
                this.settings.subscribeSlowDelayStepMs,
            ),
          key: keyByIp,
        },
        {
          kind: "limit",
          name: "sub_ip",
          windowMs: 10 * 60_000,
          limit: this.settings.subscribePer10MinPerIp,
          message: {
            error: "rate_limited",
            where: "subscribe",
            reason: "too_many_requests_ip",
          },
          key: keyByIp,
        },
        {
          kind: "limit",
          name: "sub_to",
          windowMs: 60 * 60_000,
          limit: this.settings.subscribePerHourPerTo,
          message: {
            error: "rate_limited",
            where: "subscribe",
            reason: "too_many_requests_to",
          },
          key: (request) => `to:${normalizeGetTo(request) || "missing"}`,
        },
        {
          kind: "limit",
          name: "sub_alias",
          windowMs: 60 * 60_000,
          limit: this.settings.subscribePerHourPerAlias,
          message: {
            error: "rate_limited",
            where: "subscribe",
            reason: "too_many_requests_alias",
          },
          key: (request) =>
            `alias:${normalizeGetDomain(request) || "default"}:${normalizeGetName(request) || "missing"}`,
        },
      ];
    }

    if (method === "GET" && path === "/forward/unsubscribe") {
      return [
        this.globalLimitRule(),
        {
          kind: "delay",
          name: "unsub_slow_ip",
          windowMs: 60_000,
          delayAfter: this.settings.unsubscribeSlowDelayAfter,
          delayMs: (hits) =>
            Math.max(
              0,
              (hits - this.settings.unsubscribeSlowDelayAfter) *
                this.settings.unsubscribeSlowDelayStepMs,
            ),
          key: keyByIp,
        },
        {
          kind: "limit",
          name: "unsub_ip",
          windowMs: 10 * 60_000,
          limit: this.settings.unsubscribePer10MinPerIp,
          message: {
            error: "rate_limited",
            where: "unsubscribe",
            reason: "too_many_requests_ip",
          },
          key: keyByIp,
        },
        {
          kind: "limit",
          name: "unsub_addr",
          windowMs: 60 * 60_000,
          limit: this.settings.unsubscribePerHourPerAddress,
          message: {
            error: "rate_limited",
            where: "unsubscribe",
            reason: "too_many_requests_address",
          },
          key: (request) => {
            const address = normalizeGetAddress(request);
            return address ? `unsub_addr:${address.slice(0, 254)}` : "unsub_addr:missing";
          },
        },
      ];
    }

    if (method === "GET" && path === "/forward/confirm") {
      return [
        this.globalLimitRule(),
        {
          kind: "limit",
          name: "confirm_ip",
          windowMs: 10 * 60_000,
          limit: this.settings.confirmPer10MinPerIp,
          message: {
            error: "rate_limited",
            where: "confirm",
            reason: "too_many_requests_ip",
          },
          key: keyByIp,
        },
        {
          kind: "limit",
          name: "confirm_token",
          windowMs: 10 * 60_000,
          limit: this.settings.confirmPer10MinPerToken,
          message: {
            error: "rate_limited",
            where: "confirm",
            reason: "too_many_requests_token",
          },
          key: (request) => `token:${normalizeGetToken(request) || "missing"}`,
        },
      ];
    }

    if (method === "POST" && path === "/request/ui") {
      return [
        this.globalLimitRule(),
        {
          kind: "limit",
          name: "req_ui_ip",
          windowMs: 60_000,
          limit: this.settings.requestUiPerMinPerIp,
          message: {
            error: "rate_limited",
            where: "request_ui",
            reason: "too_many_requests_ip",
          },
          key: keyByIp,
        },
        {
          kind: "limit",
          name: "req_ui_target",
          windowMs: 10 * 60_000,
          limit: this.settings.requestUiPer10MinPerTarget,
          message: {
            error: "rate_limited",
            where: "request_ui",
            reason: "too_many_requests_target",
          },
          key: (request) => `req_ui:${normalizeBodyTarget(request) || "missing"}`,
        },
      ];
    }

    if (method === "POST" && path === "/request/email") {
      return [
        this.globalLimitRule(),
        {
          kind: "limit",
          name: "req_email_ip",
          windowMs: 10 * 60_000,
          limit: this.settings.requestEmailPer10MinPerIp,
          message: {
            error: "rate_limited",
            where: "request_email",
            reason: "too_many_requests_ip",
          },
          key: keyByIp,
        },
        {
          kind: "limit",
          name: "req_email_target",
          windowMs: 60 * 60_000,
          limit: this.settings.requestEmailPerHourPerTarget,
          message: {
            error: "rate_limited",
            where: "request_email",
            reason: "too_many_requests_target",
          },
          key: (request) => `req_email:${normalizeBodyTarget(request) || "missing"}`,
        },
      ];
    }

    if (method === "GET" && /^\/api\/checkdns\/[^/]+$/.test(path)) {
      return [
        this.globalLimitRule(),
        {
          kind: "limit",
          name: "checkdns_target",
          windowMs: 10 * 60_000,
          limit: this.settings.checkdnsPer10MinPerTarget,
          message: {
            error: "rate_limited",
            where: "checkdns",
            reason: "too_many_requests_target",
          },
          key: (request) => `checkdns:${normalizeRouteTarget(request) || "missing"}`,
        },
      ];
    }

    if (method === "POST" && path === "/api/credentials/create") {
      return [
        this.globalLimitRule(),
        {
          kind: "limit",
          name: "cred_create_ip",
          windowMs: 60 * 60_000,
          limit: this.settings.credentialsCreatePerHourPerIp,
          message: {
            error: "rate_limited",
            where: "credentials_create",
            reason: "too_many_requests_ip",
          },
          key: keyByIp,
        },
        {
          kind: "limit",
          name: "cred_create_email",
          windowMs: 60 * 60_000,
          limit: this.settings.credentialsCreatePerHourPerEmail,
          message: {
            error: "rate_limited",
            where: "credentials_create",
            reason: "too_many_requests_email",
          },
          key: (request) => `cred_create:${normalizeCredentialEmail(request) || "missing"}`,
        },
      ];
    }

    if (method === "GET" && path === "/api/credentials/confirm") {
      return [
        this.globalLimitRule(),
        {
          kind: "limit",
          name: "cred_confirm_ip",
          windowMs: 10 * 60_000,
          limit: this.settings.credentialsConfirmPer10MinPerIp,
          message: {
            error: "rate_limited",
            where: "credentials_confirm",
            reason: "too_many_requests_ip",
          },
          key: keyByIp,
        },
        {
          kind: "limit",
          name: "cred_confirm_token",
          windowMs: 10 * 60_000,
          limit: this.settings.credentialsConfirmPer10MinPerToken,
          message: {
            error: "rate_limited",
            where: "credentials_confirm",
            reason: "too_many_requests_token",
          },
          key: (request) => `cred_confirm:${normalizeGetToken(request) || "missing"}`,
        },
      ];
    }

    if (
      method === "GET" &&
      ["/api/alias/list", "/api/alias/stats", "/api/activity"].includes(path)
    ) {
      return [this.globalLimitRule(), this.aliasLimitRule("alias_list_key", this.settings.aliasListPerMinPerKey, "alias_list")];
    }

    if (method === "POST" && path === "/api/alias/create") {
      return [this.globalLimitRule(), this.aliasLimitRule("alias_create_key", this.settings.aliasCreatePerMinPerKey, "alias_create")];
    }

    if (method === "POST" && path === "/api/alias/delete") {
      return [this.globalLimitRule(), this.aliasLimitRule("alias_delete_key", this.settings.aliasDeletePerMinPerKey, "alias_delete")];
    }

    return [];
  }

  private globalLimitRule(): LimitRule {
    return {
      kind: "limit",
      name: "global",
      windowMs: 60_000,
      limit: this.settings.globalPerMin,
      message: GLOBAL_LIMIT_MESSAGE,
      key: keyByIp,
    };
  }

  private aliasLimitRule(
    name: string,
    limit: number,
    where: "alias_list" | "alias_create" | "alias_delete",
  ): LimitRule {
    return {
      kind: "limit",
      name,
      windowMs: 60_000,
      limit,
      message: {
        error: "rate_limited",
        where,
        reason: "too_many_requests_key",
      },
      key: (request) => {
        const key = normalizeApiKey(request);
        return key ? `${where}:${key.slice(0, 64)}` : "";
      },
    };
  }

  private async applyDelayRule(rule: DelayRule, req: Request): Promise<number> {
    if (rule.delayAfter <= 0) {
      return 0;
    }

    const key = rule.key(req);
    if (!key) {
      return 0;
    }

    const state = await this.increment(rule.name, key, rule.windowMs);
    if (state.count <= rule.delayAfter) {
      return 0;
    }

    return rule.delayMs(state.count);
  }

  private async applyLimitRule(
    rule: LimitRule,
    req: Request,
    res: Response,
  ): Promise<boolean> {
    if (rule.limit <= 0) {
      return false;
    }

    const key = rule.key(req);
    if (!key) {
      return false;
    }

    const state = await this.increment(rule.name, key, rule.windowMs);
    if (state.count <= rule.limit) {
      return false;
    }

    res.setHeader("Retry-After", String(Math.max(1, Math.ceil(state.resetMs / 1000))));

    if (typeof rule.message === "string") {
      res.status(429).send(rule.message);
      return true;
    }

    res.status(429).json(rule.message);
    return true;
  }

  private async increment(ruleName: string, key: string, windowMs: number): Promise<CounterState> {
    const namespacedKey = `${this.redisKeyPrefix}${ruleName}:${key}`;
    const redisClient = await this.getRedisClientOrNull();
    if (redisClient) {
      try {
        const count = Number(await redisClient.incr(namespacedKey));
        let ttl = Number(await redisClient.pTTL(namespacedKey));
        if (ttl <= 0) {
          await redisClient.pExpire(namespacedKey, windowMs);
          ttl = windowMs;
        }

        return {
          count,
          resetMs: ttl,
        };
      } catch (error) {
        this.noteRedisFailure(error);
      }
    }

    return this.incrementMemory(namespacedKey, windowMs);
  }

  private incrementMemory(key: string, windowMs: number): CounterState {
    const now = Date.now();
    const existing = this.counters.get(key);

    if (!existing || existing.expiresAt <= now) {
      this.counters.set(key, {
        count: 1,
        expiresAt: now + windowMs,
      });

      this.cleanupMemoryIfNeeded(now);
      return {
        count: 1,
        resetMs: windowMs,
      };
    }

    existing.count += 1;

    return {
      count: existing.count,
      resetMs: Math.max(1, existing.expiresAt - now),
    };
  }

  private cleanupMemoryIfNeeded(now: number): void {
    if (this.counters.size < MEMORY_CLEANUP_THRESHOLD) {
      return;
    }

    for (const [key, value] of this.counters.entries()) {
      if (value.expiresAt <= now) {
        this.counters.delete(key);
      }
    }
  }

  private async getRedisClientOrNull(): Promise<RedisClientType | null> {
    if (!this.redisService.isConfigured()) {
      return null;
    }

    if (this.redisUnavailableUntil > Date.now()) {
      return null;
    }

    try {
      return await this.redisService.getClient();
    } catch (error) {
      this.noteRedisFailure(error);
      return null;
    }
  }

  private noteRedisFailure(error: unknown): void {
    this.redisUnavailableUntil = Date.now() + REDIS_BACKOFF_MS;
    this.logger.warn("ratelimit.redis.unavailable", {
      err: error,
      backoff_ms: REDIS_BACKOFF_MS,
      fallback: "memory",
    });
  }
}
