import type { Request, Response } from "express";

export type MockResponse = Response & {
  body: unknown;
  statusCode: number;
  headersMap: Map<string, string>;
};

export function createMockRequest(
  overrides: Partial<Request> & {
    body?: Record<string, unknown>;
    headers?: Record<string, unknown>;
    method?: string;
    params?: Record<string, unknown>;
    path?: string;
    query?: Record<string, unknown>;
  } = {},
): Request {
  const rawHeaders = Object.entries(overrides.headers ?? {}).reduce<Record<string, string>>(
    (acc, [key, value]) => {
      acc[key.toLowerCase()] = String(value ?? "");
      return acc;
    },
    {},
  );

  const request = {
    method: overrides.method ?? "GET",
    path: overrides.path ?? "/",
    query: (overrides.query ?? {}) as Record<string, unknown>,
    body: (overrides.body ?? {}) as Record<string, unknown>,
    params: (overrides.params ?? {}) as Record<string, unknown>,
    ip: String(overrides.ip ?? "127.0.0.1"),
    headers: rawHeaders,
    header(name: string): string | undefined {
      return rawHeaders[name.toLowerCase()];
    },
    get(name: string): string | undefined {
      return rawHeaders[name.toLowerCase()];
    },
    is(type: string): boolean {
      const contentType = rawHeaders["content-type"] ?? "";
      return contentType.toLowerCase().includes(type.toLowerCase());
    },
  } as unknown as Request;

  return Object.assign(request, overrides);
}

export function createMockResponse(): MockResponse {
  const headersMap = new Map<string, string>();
  const response = {} as MockResponse;

  response.body = undefined;
  response.statusCode = 200;
  response.headersMap = headersMap;
  response.status = (code: number) => {
    response.statusCode = code;
    return response;
  };
  response.json = (payload: unknown) => {
    response.body = payload;
    return response;
  };
  response.send = (payload: unknown) => {
    response.body = payload;
    return response;
  };
  response.end = () => response;
  response.set = (name: string, value?: string | string[]) => {
    const resolvedValue = Array.isArray(value) ? value.join(",") : String(value ?? "");
    headersMap.set(name.toLowerCase(), resolvedValue);
    return response;
  };
  response.setHeader = (
    name: string,
    value: string | number | readonly string[],
  ) => {
    const resolvedValue = Array.isArray(value) ? value.join(",") : String(value);
    headersMap.set(name.toLowerCase(), resolvedValue);
    return response;
  };
  response.getHeader = (name: string) => headersMap.get(name.toLowerCase());

  return response;
}
